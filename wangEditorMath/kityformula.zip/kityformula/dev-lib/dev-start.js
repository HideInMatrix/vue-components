/**
 * Created by hn on 13-12-4.
 */
// 启动脚本
inc.use( 'kf.start' );