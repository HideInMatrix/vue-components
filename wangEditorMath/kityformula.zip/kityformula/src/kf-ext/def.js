/**
 * Created by hn on 14-3-18.
 */

define( function () {

    return {
        selectColor: 'rgba(42, 106, 189, 0.2)',
        allSelectColor: 'rgba(42, 106, 189, 0.6)'
    };

} );