/*!
 * 虚拟组列表
 */

define( function () {

    return {

        "radical": true,
        "fraction": true,
        "summation": true,
        "integration": true,
        "placeholder": true,
        "script": true,
        "superscript": true,
        "subscript": true,
        "brackets": true,
        "function": true

    };

} );