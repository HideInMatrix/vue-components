/*!
 * box类型定义
 */

define( function ( require ) {

    return {
        // 分离式
        "DETACHED": 1,
        // 重叠式
        "OVERLAP": 2
    };

} );